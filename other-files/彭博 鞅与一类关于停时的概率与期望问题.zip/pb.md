## 2	鞅与鞅的停时定理

#### 2.1 鞅

**定义 2.1.1**（随机过程）：对于每一个参数 $t \in T$ ，$X(t, \omega)$ 是一随机变量，称随机变量族 $X_T = \{X(t, \omega), t \in T\}$ 为一**随机过程**。其中$T \subset \mathbb{R}$ 是一实数集，称为指标集。其中，$X(t, \omega)$ 一般可以简记为 $X_t$。

参数 $t \in T$ 一般表示时间或空间。在本文中，只考虑参数为离散时间的随机过程， 即可以取 $T = \mathbb{N}$ 。

**定义 2.1.2**：称随机过程 $X=\{X_n， n \ge 0\}$ 是**鞅**，若：

1.  $\forall n \ge 0,E(|X_n|)<\infty$
2.  $\forall n \ge 0,E(X_{n+1}\mid X_0,\cdots,X_n)=X_n$

**定义 2.1.3**：称随机过程 $Y=\{Y_n, n \ge 0\}$ 是关于随机过程 $X=\{X_n, n \ge 0\}$ 是**鞅**，若：

1.  $\forall t\ge 0,E(|Y_t|)<\infty$
2.  $\forall t\ge 0,E(Y_{t+1}-Y_t\mid X_0,\cdots,X_t)=0$

直观来讲，鞅是满足下述条件的随机过程：已知过去的某个时刻 $s$ 及 $s$ 之前的所有观测值，对于以后的任意时刻 $t$ ，$t$ 的观测值的条件期望等于 $s$ 的观测值。

**例子 2.1.4**（数轴上的随机游走）：令 $X_0=0$ ，${X_k, k\ge 1}$ 独立同分布且 $P(X_k = 1) = p \ge 0, P(X_k = -1) = q = 1 - p \ge 0$。记$Y_n = \sum_{k=0}^{n}X_k$ ，则 $\{Y_n, n \ge 0\}$ 表示一个粒子以 0 为起始点的在数轴上的随机游走过程， $Y_n$ 为 $n$ 时刻的坐标。

（1）若给定的 $p = q = \frac{1}{2}$，那么 $Y=\{Y_n, n \ge 0\}$ 是鞅，并且设 $Z_n=Y_n^2-n$ 。 $Z=\{Z_n, n \ge 0\}$ 是关于 $\{Y_n, n \ge 0\}$ 的鞅。

证明：$\forall n \ge 0$ ，
$$
\begin{align}
E(|Y_n|) &= E(|\sum_{k=0}^{n}X_k|) \\
&\le E(\sum_{k=0}^{n}|X_k|) = n < \infty \\
E(Y_{n+1}\mid Y_0,\cdots,Y_n) &= E(Y_n + X_{n+1}\mid Y_0,\cdots,Y_n) \\
&= Y_n + E(X_{n+1}\mid Y_0,\cdots,Y_n) \\
&= Y_n + E(X_{n+1}) \\
&= Y_n
\end{align}
$$
因此 $Y=\{Y_n, n \ge 0\}$ 是鞅。

类似地也有
$$
\begin{align}
E(|Z_n|) &= E(|Y_n^2 - n|) \\
&\le E(Y_n^2)+n \\
&\le n^2 + n < \infty \\
E(Z_{n+1}\mid Y_0,\cdots,Y_n) &= E(Y_{n+1}^2 - n - 1 \mid Y_0,\cdots,Y_n) \\
&= E((Y_n + X_{n+1})^2 - n - 1 \mid Y_0,\cdots,Y_n) \\
&= E(Y_n^2 + X_{n+1}^2 - 2X_{n+1}Y_n - n - 1 \mid Y_0,\cdots,Y_n) \\
&= Y_n^2 + 1 -2E(X_{n+1})Y_n - n - 1 \\
&= Y_n^2 - n \\
&= Z_n
\end{align}
$$
因此，$Z=\{Z_n, n \ge 0\}$ 是关于 $\{Y_n, n \ge 0\}$ 的鞅。

（2）若给定的 $p \neq q$，那么设 $W_n=(\frac{q}{p})^{Y_n}$ ，则 $W=\{W_n, n \ge 0\}$ 是关于 $\{Y_n, n \ge 0\}$ 的鞅。

证明：$\forall n \ge 0$ ，
$$
\begin{align}
E(|W_n|) &= E(|(\frac{q}{p})^{Y_n}|) \\
&\le (\frac{q}{p})^n < \infty \\
E(W_{n+1} \mid Y_0,\cdots,Y_n) &= E(W_n(\frac{q}{p})^{X_{n+1}} \mid Y_0,\cdots,Y_n) \\
&= W_n E((\frac{q}{p})^{X_{n+1}} \mid Y_0,\cdots,Y_n) \\
&= W_n (p\cdot \frac{q}{p} + p \cdot \frac{q}{p}) \\
&= W_n
\end{align}
$$
因此，$W=\{W_n, n \ge 0\}$ 是关于 $\{Y_n, n \ge 0\}$ 的鞅。

#### 2.2 鞅的停时定理

**定义 2.2.1**（随机时刻）：设取值为非负整数（包括 $+\infty$ ）的随机变量 $T$ ，及随机过程 $\{X_n, n \ge 0\}$ ，若 $\forall n \ge 0$ ，事件 $\{T = n\}$ 的示性函数 $I_{\{T=n\}}$ 仅是 $X_0, X_1, \cdots, X_n$ 的函数，则称 $T$ 是随机过程 $\{X_n ,n \ge 0\}$ 的**随机时刻**。

**定义 2.2.2**（停时）：若 $T$ 是随机过程 $\{X_n ,n \ge 0\}$ 的随机时刻，并且有 $P(T < \infty) = 1$ ，则称 $T$ 是随机过程 $\{X_n ,n \ge 0\}$ 的**停时**。

**定义 2.2.3**（停止过程）：若 $T$ 是对过程 $\{X_n, n\ge 0\}$ 的一个随机时刻，且令
$$
\bar{X}_{n}=\left\{\begin{array}{ll}
X_{n}, &  n \le T \\
X_{T}, &  n > T
\end{array}\right.
$$
则称 $\{\bar{X}_n\}$ 为**停止过程**。

**命题 2.2.4**：如果 $T$ 是鞅 $\{X_n, n \ge 0\}$ 的一个随机时刻，则停止过程 $\{\bar{X}_n， n\ge 0\}$ 也是关于 $\{X_n, n \ge 0\}$ 的一个鞅。

证明：$\forall n \ge 0$ ，若 $n \lt T$ ，则有 $\bar{X}_{n+1} - \bar{X}_n = X_{n+1} - X_n$ ；若 $n \ge T$ ，则有 $\bar{X}_{n+1}  - \bar{X}_n = 0$ ，从而
$$
\begin{align}
E(\bar{X}_{n+1}\mid X_0, X_1, \cdots, X_n) &= E(\bar{X}_{n+1} - \bar{X}_n + \bar{X}_n\mid X_0, X_1, \cdots, X_n) \\
&= E(\bar{X}_{n+1} - \bar{X}_n \mid X_0, X_1, \cdots, X_n) + \bar{X}_n \\
\end{align}
$$
由于 $\{X_n, n \ge 0\}$ 是鞅，因此 $E(X_{n+1} - X_n \mid X_0, X_1, \cdots, X_n) = 0$ ，从而无论 $n$ 与 $T$ 关系如何，都有
$$
E(\bar{X}_{n+1}\mid X_0, X_1, \cdots, X_n) = \bar{X}_n
	
$$
也即停止过程 $\{\bar{X}_n， n\ge 0\}$ 关于 $\{X_n, n \ge 0\}$ 是鞅。

**定理 2.2.5** （鞅的停时定理）：设 $X = \{X_n, n \ge 0\}$ 是一个离散时间鞅，$T \in \mathbb{N} \cup \{\infty\}$ 是停时，若有下列条件之一成立

（1） $\bar{X}_n$ 一致有界；

（2）$T$ 有界；

（3）$E(T)<\infty$ ，且存在 $M<\infty$ 使 $E(|X_{n+1}-X_n|\mid X_0,\cdots,X_n)<M$ ；

那么，
$$
E(X_T)=E(X_0)
$$
**定义 2.2.6**（非降 $\sigma$-代数族）：记随机过程 $X = \{X_n, n \ge 0\}$ ，令 $\mathcal{F}_{n}:=\sigma(X_{k} \mid k \leq n)$ ，则称 $\mathcal{F} = \{\mathcal{F}_n， n\ge 0\}$ 是 $X$ 导出的一个**非降 $\sigma$-代数族**。

**定理 2.2.7**（更一般的鞅的停时定理）：设$\mathcal{F} = \{\mathcal{F}_n， n\ge 0\}$ 是一个非降 $\sigma$-代数族，$X = \{X_n, n\ge 0\}$ 和 $T \in \mathbb{N} \cup \{\infty\}$ 分别是关于 $\mathcal{F}$ 的鞅和停时，若有下列条件之一成立

（1） $T$ 几乎处处有界，即存在 $c \in \mathbb{N}$ ，$T \le c$ 几乎处处成立；

（2）$E(T)<\infty$ ，且存在 $M<\infty$ 使 $E(|X_{n+1}-X_n|\mid \mathcal{F}_n)<M$ ；

（3）存在 $c \in \mathbb{N}$ 使得 $\forall T \in \mathbb{N}, |X_{n \and T}| \le c$ 几乎处处成立，其中 $n \and T := min(n, T)$ ；

那么，
$$
E(X_T)=E(X_0)
$$
鞅的停时定理说明，即使随机过程非常复杂，甚至可能趋向无穷，只要满足某些条件，那么还是可以得到终态的某些性质。

**例子 2.2.8**（不均衡赌本与不公平赌博问题）：设甲乙两个人赌博，他们原有的赌本资金 $a, b \in \mathbb{N}$ ，每次赌博输家需要向赢家支付一单位资金，每次赌博之间相互独立，一次赌博中，甲的取胜概率为 $p$ ，乙的取胜概率为 $q = 1 - p$ 。根据鞅的停时定理，可以得到甲和乙输光自己所有赌本的概率以及平均赌博次数。

不难看出，这依然是一个随机游走的模型，沿用**例子2.1.4**中的记号，粒子从 0 出发，并且每个单位时间在数轴上向右或向左分别以概率 $p$ 和概率 $q = 1 - p$ 移动一个单位的长度。记 $T_u = \min\{n: Y_0 = 0, Y_n = u\}$ ，且 $T = \min\{n: Y_0 = 0, Y_n = -a \ 或\  Y_n= b\}$，那么平均赌博次数就是甲和乙任何一方输光自己所有赌本的平均时间，即为 $E(T)$；记 $_uT_v = \min\{n: Y_0 = 0, Y_l \neq u, 1 \le l \le n-1, Y_n = v\}$ ，则概率 $V_{-a} = P(_{b}T_{-a} < \infty \mid Y_0 = 0)$ 表示粒子从 0 出发相对于 $u$ 先到达 $v$ 的概率，类似地 $V_b = P({_-a}T_{-b} < \infty \mid Y_0 = 0)$ 。从而 $V_a + V_b = 1$。利用 $Z=\{Z_n, n \ge 0\}$ 和 $W=\{W_n, n \ge 0\}$ 分别在 $p=q=\frac{1}{2}$ 和 $p \neq q$ 的情况下是关于 $\{Y_n, n \ge 0\}$ 的鞅，结合停时定理，就可以得到上述几个值，具体证明此处不在赘述，有兴趣的读者可以参考[5]中给出的证明。

## 3	例题分析

#### 3.1 猴子打字问题

##### 3.1.1 问题描述

给定大小 $|\Sigma|=26$ 的字符集以及长度为 $n$ 的串 $s$ 。令字符串 $t$ 初始为空，每次在 $t$ 后面随机拼接 $\Sigma$ 中的一个字符，求 $s$ 第一次成为 $t$ 的后缀的期望时间。

##### 3.1.2 问题解析

通过经典的概率生成函数做法，可以求出答案为 $\sum_{i=1}^{n} I_{s[1,i]=s[n-i+1,n]}|\Sigma|^i$ ，其中 $s[l,r]$ 表示 $s$ 的子串 $s_ls_{l+1}\dots s_r$ 。这里用停时定理给出另外一种证明。

假设每个时刻有一个赌徒带着 1 美元入场，并押这一次随机加入的字符是 $s_1$ 。如果没有押中那么输光离场，否则资金乘上 $|\Sigma|$ ，并在下一次用全部资金押加入的字符为 $s_2$ ，如果继续押中了就继续用全部资金押 $s_3$ ，以此类推。当某个赌徒押中了 $s_n$ ，则结束。

容易发现每个赌徒每一次的期望收益都是 0 ，在 $t_m$ 公布后 $t_{m+1}$ 公布前这一时刻，设所有赌徒的总财富为 $A_m$ ，那么由于每个时刻会新出现一个持有一美元的赌徒，易知 $\{A_m-m,m\ge 0\}$ 是一个鞅。

设 $T=\min\{m:t[m-n+1,m]=s\}$ ，则 $T$ 是一个停时，并且注意到 $A_{m \and T}  \le \sum_{i=1}^n |\Sigma|^i$ 有界，根据停时定理有，
$$
\begin{align*}
E[A_T-T]&=E[A_0-0]=0\\
A_T&=\sum_{i=1}^{n} I_{s[1,i]=s[n-i+1,n]}|\Sigma|^i
\end{align*}
$$
所以 $E[T]=\sum_{i=1}^{n} I_{s[1,i]=s[n-i+1,n]}｜\Sigma｜^i$ 。

#### 3.2 Company Acquisitions

##### 3.2.1 问题描述

有 $m$ 个人组成若干个小组，每个小组由若干个组员和一个组长组成，初始分组情况给定。在只剩下一个小组之前反复执行以下操作：等概率随机选取两个不同的组长，然后让其中一位组长加入另一个小组并成为组员，该组长原来的小组中所有的组员各自组成一个只有其自己的新小组并成为其组长，求只剩一个小组时所需要的平均操作次数。

##### 3.2.2 问题解析

假设某一小组有 $x$ 个组员（不包含组长），定义它的**势**为 $2^x-1$ 。注意到一次操作中，设选取出来的两个组长为 $A,B$ ，其原来各自的小组中组员数量分别为 $a, b$ ，那么若一次操作双方之后势的期望变化量
$$
{1\over 2}((2^{b+1}-1)+(a-1)(2^0-1))+{1\over 2}((2^{a+1}-1)+(b-1)(2^0-1))-((2^a-1)+(2^b-1))=1
$$
$\forall n\ge 0$ ，记 $X_n$ 为经过 $n$ 次操作之后所有小组的势的和， $Y_n=X_n-n$ ，那么 $E[Y_n]<\infty$ ，易证 $Y=\{Y_n,n\ge 0\}$ 是鞅。设停时 $T=\min\{n: 经过\ n\ 次操作后只剩一个小组\}$ 。不难证明 $X_n \le 2^m - 1$ ，因此 $E[|Y_{n+1}-Y_n|]$ 有界。而  $E[|Y_n|]=E[Y_n]<\infty$ ，且 $E[T]<\infty$ ，由停时定理有，

$$
\begin{align}
E[Y_T] &= E[Y_0] \\
E[X_T]-E[T] &= E[X_0]
\end{align}
$$
而 $E[X_T]=2^m-1$ ， $E[Y_0]=X_0$ 给定，由此马上可以得到 $E[T]$ 。

#### 3.3 Slime and Biscuits

##### 3.3.1 问题描述

有 $n$ 个人，每个人初始有 $a_i$ 个球。在每一秒，随机选择一个球并把它交给另一个人。当某个人获得所有球时此人胜出，停止游戏。求游戏进行时长的期望。 

##### 3.3.2 问题解析

本题的一个关键性质是，如果只考虑一个人的球数的变化，那么不需要知道其他人的具体状态就可以求出这个人经过一步之后的球数的概率分布，也就是说每个人的状态之间相互是独立的。另外一个特点是每一步对当前状态的影响比较小，只会使两个人的球数加减一。

###### 3.3.2.1 官方题解

设 $E_x$ 表示 $x$ 胜出时总时长的条件期望，那么答案即为 $\sum_{i=1}^n E_i$ 。

设 $E'_x$ 表示，如果修改游戏规则，只有 $x$ 胜出时才停止游戏，游戏时长的期望。

设 $P_x$ 为 $x$ 胜出的概率，显然有 $\sum_{i=1}^n P_i=1$ 。

设常数 $C$ 表示所有球从一个人手中转移到至另一个指定的人中的期望时间。

考虑 $E'_x$ 比 $E_x$ 多算了什么，发现恰好是所有球先集中到某个人的手上，再全部转移过来，的期望时间。所以可以发现有以下恒等式
$$
E_x=E'_x-\sum_{i=1 \\ i \neq x}^n(E_i+P_iC)
$$
移项得到
$$
\sum_{i=1}^n E_i=E'_x-C(1-P_x)
$$
将等式对 $x=1,2,\cdots,n$ 求和，得到
$$
n\sum_{i=1}^n E_i=\sum_{i=1}^n E'_i-C(n-1)
$$
所以问题转化为求 $E'_x$ 和 $C$ 。

求 $E'_x$ 和 $C$ 时，由前述的关键性质，可以设 $g_i$ 表示 $x$ 现在有 $i$ 个球，到第一次有 $i+1$ 个球的期望时间。设 $m=\sum_{i=1}^n  a_i$ ，有方程
$$
g_i=1+{(n-2)(m-i)\over (n-1)m}g_i+{i\over m}(g_{i-1}+g_i),0<i<m
$$
可以从这个方程解出 $g_i$ 关于 $g_{i-1}$ 的递推式
$$
g_i={m(n-1)\over m-i}+{(n-1)i\over m-i}g_{i-1},0<i<m
$$
有初始值 $g_0=n-1$ 。

然后设 $f_i=\sum_{k=i}^{m-1} g_k$ ，得到 $E'_x=f_{a_x},C=f_0$ ，从而求出答案。

###### 3.3.2.2 问题再解——基于鞅的停时定理

设经过 $t$ 步之后的状态是 $A_t$ ，其中每个人的球数为 $a_{t,i}$ 。设 $m$ 为总球数。

考虑类似 **3.1** 节中的做法，构造**势函数** $\phi$ ，使得 $\mathbb{E}[\,\phi(A_{t+1})+(t+1)\mid A_{t}, \ldots, A_{0}\,]=\phi(A_t)+t$ ，然后运用停时定理求出 $E(T)$ 。

在本例中，可以设 $\phi(A_t)=\sum f(a_{t,i})$ ，其中 $f$ 是一个需要构造的函数。

显然 $E[\phi(A_{t+1})]$ 只和 $E[\phi(A_t)]$ 有关，所以 $E\left[\phi\left(A_{t+1}\right) \mid A_{t}, \ldots, A_{0}\right]=E\left[\phi\left(A_{t+1}\right) \mid A_{t}\right]$ 。

为了求出 $E\left[\phi\left(A_{t+1}\right) \mid A_{t}\right]$ ，可以枚举每一种情况，得到
$$
\begin{aligned}
E\left[\phi\left(A_{t+1}\right) \mid A_{t}\right] &=\sum_{i} \sum_{j \neq i} \frac{a_{t, i}}{m(n-1)}\left[f\left(a_{t, i}-1\right)+f\left(a_{t, j}+1\right)+\sum_{k \notin\{i, j\}} f\left(a_{t, k}\right)\right] \\
&=\sum_{i}\left[\frac{a_{t, i}}{m} f\left(a_{t, i}-1\right)+\frac{m-a_{t, i}}{m(n-1)} f\left(a_{t, i}+1\right)+\frac{\left(m-a_{t, i}\right)(n-2)}{m(n-1)} f\left(a_{t, i}\right)\right]
\end{aligned}
$$
令 $E[\,\phi(A_{t+1})-\phi(A_t)\mid A_t\,]=-1$ ，得到
$$
\begin{align*}
\sum_{i} f\left(a_{t, i}\right)&=1+\sum_{i}\left[\frac{a_{t, i}}{m} f\left(a_{t, i}-1\right)+\frac{m-a_{t, i}}{m(n-1)} f\left(a_{t, i}+1\right)+\frac{\left(m-a_{t, i}\right)(n-2)}{m(n-1)} f\left(a_{t, i}\right)\right]\\
&=\sum_{i}\left[\frac{a_{t, i}}{m} f\left(a_{t, i}-1\right)+\frac{m-a_{t, i}}{m(n-1)} f\left(a_{t, i}+1\right)+\frac{\left(m-a_{t, i}\right)(n-2)}{m(n-1)} f\left(a_{t, i}\right)+\frac{a_{t, i}}{m}\right]
\end{align*}
$$
注意这里把 $1$ 拆成了 $\sum {a_i\over m}$ ，可以使得每个 $a_i$ 互不影响。当然，换成 $\sum {1\over n}$ 或是其他和为 $1$ 的值都是可以的。

于是构造 $f(a)$ 满足
$$
f(a)=\frac{a}{m} f(a-1)+\frac{m-a}{m(n-1)} f(a+1)+\frac{(m-a)(n-2)}{m(n-1)} f(a)+\frac{a}{m}
$$
移项得到
$$
f(a+1) = \left[ \frac {m(n-1)} {m-a} - (n-2) \right] f(a) - \frac {a(n-1)} {m-a} \left( f(a-1)+1 \right)
$$
将 $a=0$ 代入可以得到 $f(0)=f(1)$ ，所以初值可以取 $f(0)=f(1)=0$ ，或是其他任意一个数。然后递推即可得到 $f$ 的所有函数值。

$a=m$ 时并不满足这个式子，但由于出现 $a=m$ 时随机过程一定已经停止了，所以这个条件不需要被满足。

现在设 $X_t=\phi(A_t)+t$ ，就有 $E[X_{t+1}-X_t \mid A_t]=0$ ，另一方面， 由于 $X_t=\phi(A_t)+t$ ， $\phi(A_t)$ 有界且 $t$ 非负，所以 $0\le |X_t|\le X_t+2|\phi|_{\max}$ ，所以 $E[|X_t|]<\infty$ ，从而根据定义知道 $\{X_t, t \ge 0\}$ 关于 $\{A_t, t \ge 0\}$ 是一个鞅。

另一方面，由于这个随机过程可以看做在一张确定的图上随机游走，状态数有限，且每个点都可以到达终点，由常返马氏链的性质知道 $\mathbb{E}[T]<\infty$ 。而 $\mathbb{E}[|X_{n+1}-X_n|\mid A_0,\cdots,A_n]=1+\mathbb{E}[|\phi(A_{n+1})-\phi(A_n)|\mid A_0,\cdots,A_n]$ 有界，因此可以应用停时定理，得到 

$E[X_T]=\phi(A_T)+E[T]=E[X_0]=\phi(A_0)$ 。由于 $\phi(A_0),\phi(A_T)$ 都是定值，所以有 $E[T]=\phi(A_0)-\phi(A_T)$ ，即
$$
E[T]=\sum_{i} f\left(a_{0, i}\right)-(f(m)+(n-1) f(0))
$$

在官方题解中，为什么定义 $E'_x$ ，以及定义了 $E'_x$ 之后有什么用，并不是非常清晰；而基于鞅的停时定理的做法，从问题中每个人状态之间的相互独立性出发，引导势函数 $\phi(A)=\sum_{i=1}^n f(a_i)$ 的构建，使整个解题思路有迹可循，这体现了鞅论可以帮助思考和解决与随机过程相关的赛题。

#### 3.4 Slime and Biscuits Strikes Back 

##### 3.4.1 问题描述

有 $n$ 个人，每个人初始有 $a_i$ 个球。在每一秒，随机选择一个球并把它交给另一个人。当某个人获得所有球时此人胜出，停止游戏。对于每个人，求游戏停止时所有球在这个人手上的概率。

##### 3.4.2 问题解析

事实上，**3.3.2.1** 节中的推导已经解决这一问题，沿用其记号，考虑在上文中的式子

$$
\sum_{i=1}^n E_i=E'_x-C(1-P_x)
$$
由于 $\sum_{i=1}^n E_i=E[T]$ 已知，而 $E'_x,C$ 也都可以被求出来，所以可以解出 $P_x$ ，复杂度 $O(n+\sum a_i)$ 。

下面通过鞅论给出另一种思路更加直接的解答：

设 $p_i$ 表示球最终聚集在第 $i$ 个人手上的概率。类似**例子2.2.8**，考虑通过鞅和停时定理构造出关于 $p_i$ 的 $n$ 个方程，解出所有 $p_i$ 。

仍然设经过 $t$ 步之后的状态是 $A_t$ ，其中每个人的球数为 $a_{t,i}$ ， $m = \sum a_i$ 为总球数。设 $B_i$ 表示所有球都聚集到 $i$ 手上的状态。

###### 3.4.2.1 构造一

继续沿用之前构造势函数的方法，但为了区分不同的位置，要给每个位置构造不同的势函数，设 $\phi(A_t)=\sum_i f_i(a_{t,i})$ ，并直接令 $\{\phi(A_t),t\ge 0\}$ 为鞅。用例题三的方法，可以推导出

$$
\begin{align*}
f(1)&=f(0)\\
f(a+1) &= \left[ \frac {m(n-1)} {m-a} - (n-2) \right] f(a) - \frac {a(n-1)} {m-a} f(a-1)&1\le a<m
\end{align*}
$$
而应用鞅的停时定理，有方程
$$
E[\phi(A_T)]=\sum_{i=1}^n p_i\phi(B_i)=\phi(A_0)
$$
考虑给每个 $i$ 随机 $f_i(0)$ ，即可得到一个方程，重复 $n$ 次即可得到 $n$ 个方程。

但是这个做法出现了一个重大的漏洞：这 $n$ 个方程组成的矩阵不满秩。由于递推式中 $f(a)$ 和 $f(a-1)$ 的系数相加恰好是 1 ，我们其实解出了 $f(a)=f(0),\forall 1\le a\le m$ ，因此无法解出这一方程组。事实上，由于在每个 $f_i$ 中自由度为 1，因此合法的 $f$ 只有常数序列。

###### 3.4.2.2 构造二

考虑对所构造鞅的形式进行微调，设 $\phi(A_t)=\sum_i f_i(a_{t,i})$ ，并令 $\{\phi(A_t)+t,t\ge 0\}$ 为鞅，类似地，
$$
\begin{align*}
f(1)&=f(0)\\
f(a+1) &= \left[ \frac {m(n-1)} {m-a} - (n-2) \right] f(a) - \frac {a(n-1)} {m-a} (f(a-1)+1)&1\le a<m
\end{align*}
$$
而应用鞅的停时定理，有方程
$$
\begin{align*}
E[\phi(A_T)]&=\sum_{i=1}^n p_i\left(\phi(B_i)+E[T\mid A_T=B_i]\right)\\
&=E[T]+\sum_{i=1}^n p_i\phi(B_i)\\
&=\phi(A_0)
\end{align*}
$$
同样可以通过随机 $f_i(0)$ 获得 $n$ 个方程，遗憾的是，这与思路一并没有本质上的区别。由于方程中的系数相加依然为 1，这一构造获得的序列仅仅是在 $f(0)=0$ 导出的序列的基础上加上一个常数序列而已。

###### 3.4.2.3 构造三

回顾 **3.4.2.2**节中 $f$ 的构造，关注这一步：
$$
\begin{align*}
\sum_{i} f\left(a_{t, i}\right)&=1+\sum_{i}\left[\frac{a_{t, i}}{m} f\left(a_{t, i}-1\right)+\frac{m-a_{t, i}}{m(n-1)} f\left(a_{t, i}+1\right)+\frac{\left(m-a_{t, i}\right)(n-2)}{m(n-1)} f\left(a_{t, i}\right)\right]\\
&=\sum_{i}\left[\frac{a_{t, i}}{m} f\left(a_{t, i}-1\right)+\frac{m-a_{t, i}}{m(n-1)} f\left(a_{t, i}+1\right)+\frac{\left(m-a_{t, i}\right)(n-2)}{m(n-1)} f\left(a_{t, i}\right)+\frac{a_{t, i}}{m}\right]
\end{align*}
$$
注意到第二个等号的右边并不是唯一合法的结果。除了把 $1$ 拆成 $\sum {a_{t,i}\over m}$ ，还可以拆成其他和为 $1$ 的组合。

那么不妨随机 $\{w_i,1\le i\le n\}$ 使得 $\sum_{i=1}^n w_i=1$ ，然后令
$$
f_i(a)=\frac{a}{m} f_i(a-1)+\frac{m-a}{m(n-1)} f_i(a+1)+\frac{(m-a)(n-2)}{m(n-1)} f_i(a)+w_i\\
$$
解得
$$
\begin{align*}
f_i(1)&=f(0)-(n-1)w_i\\
f_i(a+1)&= \left[ \frac {m(n-1)} {m-a} - (n-2) \right] f_i(a) - \frac {a(n-1)} {m-a} f_i(a-1)-{m(n-1)w_i\over m-a}&1\le a<m
\end{align*}
$$
不妨设 $f(0)=0$ ， $F$ 为 $w=1$ 时得到的 $f$ ，那么有 $f_i(a)=w_iF(a)$ 。 随机 $w_i$ 并重复 $n$ 次这一过程，即可得到 $n$ 个线性无关的方程（否则可以再次随机 $w_i$ 寻求新的方程），并解出 $p_i$ 。这一方法的时间复杂度 $O(n^3+m)$ 。

尽管随机 $w_i$ 的做法可以得到 $n$ 个线性无关的方程使得 $p_i$ 可解，但是得到的方程组可能十分复杂。考虑在第 $k$ 个方程中令 $w_i=I_{\{i=k\}}$ ，那么得到的方程组的系数矩阵中只有主对角线有值，显然也是满秩可解的，此时可以直接得到 $p_i={F(a_i)-E\over F(m)}$ ，从而也在 $O(n+m)$ 的复杂度内解决了该问题。

## 参考文献

[1] 一类概率期望问题的杀器：势函数和鞅的停时定理. https://www.cnblogs.com/TinyWong/p/12887591.html

[2] Optional Stopping Theorem. https://en.wikipedia.org/wiki/Optional_stopping_theorem

[3] Martingale. https://en.wikipedia.org/wiki/Martingale_(probability_theory)

[4] The martingale Stopping Theorem. https://math.dartmouth.edu/~pw/math100w13/lalonde.pdf

[5] 林元烈，应用随机过程

[6] 何书元，随机过程